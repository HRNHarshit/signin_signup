import Google from "./google logo 1.png";
import Twitter from "./twitter logo 1.png";
import World from "./world.png";
import Logo from "./Logo.webp";

export { Google, Twitter, World, Logo };
