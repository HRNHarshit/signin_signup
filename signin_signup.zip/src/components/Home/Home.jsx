import React from "react";
import { Navbar } from "../index";

const Home = () => {
  return (
    <div className="Home">
      <Navbar />

      <div></div>
    </div>
  );
};

export default Home;
